/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuentabancaria;

/**
 *
 * @author rolbi
 */
public class Main {
     public static void main(String[] args) { //punto incial del programa
        // Crear una nueva cuenta bancaria
        CuentaBancaria cuenta = new CuentaBancaria("123456789", 1000.0);// instancia numero de cuenta & saldo inicial

        // Depositar dinero
        cuenta.depositar(500.0);
        System.out.println("Saldo después de depositar: " + cuenta.consultarSaldo());

        // Retirar dinero
        cuenta.retirar(200.0);
        System.out.println("Saldo después de retirar: " + cuenta.consultarSaldo());

        // Intentar retirar más dinero del disponible
        cuenta.retirar(1500.0);
        System.out.println("Saldo después de intentar retirar más del disponible: " + cuenta.consultarSaldo());
    }
}
    
