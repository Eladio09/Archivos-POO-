/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productos;

/**
 *
 * @author rolbi
 */
public class Productos {
    private String nombre;
    private double codigo;
    private double precio;
    
    public Productos(String nombre, double codigo, double precio){
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;     
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCodigo(double codigo) {
        this.codigo = codigo;
    }


    public double getCodigo() {
        return codigo;
    }


    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0){
            System.out.println("Precio Invalido: ");
            
        } else { 
            this.precio = precio;
            System.out.println("el producto"+",Codigo: " +codigo + ", nombre:"+nombre + ",tiene un nuevo precio de :"+precio );
            
        
        }
    }
    
 
        
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Productos productos1 = new Productos("Galletas Oreo", 4587, 100);
        productos1.setPrecio(500);
        
        // TODO code application logic here
    }
}
