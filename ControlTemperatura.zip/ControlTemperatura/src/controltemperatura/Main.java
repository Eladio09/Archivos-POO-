/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controltemperatura;

/**
 *
 * @author rolbi
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ControlTemperatura controltemperatura = new ControlTemperatura((int)25.0);
        
        System.out.println("temperatura en celcius: " + controltemperatura.getTemperatura());
        
        System.out.println("temperatura en Fahrenheit: " + controltemperatura.convertirAFahrenheit());
        
        System.out.println("Temperatura en Kelvin: " + controltemperatura.convertirAKelvin());
        
        controltemperatura.setTemperaturaCelsius((int) 30.0);
        System.out.println("Nueva temperatura en Celsius: " + controltemperatura.getTemperaturaCelsius());
        System.out.println("Nueva temperatura en Fahrenheit: " + controltemperatura.convertirAFahrenheit());
        System.out.println("Nueva temperatura en Kelvin: " + controltemperatura.convertirAKelvin());
    }
    
}
