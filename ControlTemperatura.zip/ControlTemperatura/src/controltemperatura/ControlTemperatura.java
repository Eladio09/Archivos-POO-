/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controltemperatura;

/**
 *
 * @author rolbi
 */
public class ControlTemperatura {

    //private double temperatura;
    private int temperaturaCelsius;
    
    
    public ControlTemperatura(int temperaturaCelcius){
        this.temperaturaCelsius = temperaturaCelsius;
        
    }

    public double getTemperaturaCelsius() {
        return temperaturaCelsius;
    }

    public void setTemperaturaCelsius(int temperaturaCelsius) {
        this.temperaturaCelsius = temperaturaCelsius;
    }

    public double convertirAFahrenheit() {
        return (temperaturaCelsius * 9/5) + 32;
    }

    
    public double convertirAKelvin() {
        return temperaturaCelsius + 273.15;
    
}

    int getTemperatura() {
return temperaturaCelsius;
    }

    

  
}

