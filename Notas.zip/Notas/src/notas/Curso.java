/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notas;
import java.util.ArrayList;
import java.util.List;

public class Curso {
    private List<Estudiante> estudiantes;

    // Constructor
    public Curso() {
        this.estudiantes = new ArrayList<>();
    }

    // Método para agregar un estudiante
    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    // Método para calcular el promedio del curso
    public double calcularPromedio() {
        double suma = 0;
        for (Estudiante estudiante : estudiantes) {
            suma += estudiante.getNotaFinal();
        }
        return estudiantes.size() > 0 ? suma / estudiantes.size() : 0;
    }

    // Método para obtener la lista de estudiantes que aprobaron
    public List<Estudiante> obtenerEstudiantesAprobados() {
        List<Estudiante> aprobados = new ArrayList<>();
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getNotaFinal() >= 61) {
                aprobados.add(estudiante);
            }
        }
        return aprobados;
    }
}