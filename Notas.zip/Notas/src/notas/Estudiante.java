/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notas;

/**
 *
 * @author rolbi
 */
public class Estudiante {
    private String nombre;
    private String carnet;
    private double notaFinal;

    // Constructor
    public Estudiante(String nombre, String carnet, double notaFinal) {
        this.nombre = nombre;
        this.carnet = carnet;
        setNotaFinal(notaFinal); // Usamos el setter para validar la nota
    }

    // Métodos getter y setter
    public String getNombre() {
        return nombre;
    }

    public String getCarnet() {
        return carnet;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        if (notaFinal >= 0 && notaFinal <= 100) {
            this.notaFinal = notaFinal;
        } else {
            throw new IllegalArgumentException("La nota debe estar entre 0 y 100.");
        }
    }
}