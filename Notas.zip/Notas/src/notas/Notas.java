/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notas;

import java.util.List;

/**
 *
 * @author rolbi
 */
public class Notas {
    public static void main(String[] args) {
        // Crear una instancia de Curso
        Curso curso = new Curso();

        // Crear y agregar estudiantes
        curso.agregarEstudiante(new Estudiante("Juan", "2021001", 85));
        curso.agregarEstudiante(new Estudiante("Ana", "2021002", 92));
        curso.agregarEstudiante(new Estudiante("Luis", "2021003", 58));

        // Calcular y mostrar el promedio del curso
        System.out.println("Promedio del curso: " + curso.calcularPromedio());

        // Obtener y mostrar los estudiantes que aprobaron
        List<Estudiante> aprobados = curso.obtenerEstudiantesAprobados();
        System.out.println("Estudiantes que aprobaron:");
        for (Estudiante estudiante : aprobados) {
            System.out.println(estudiante.getNombre() + " - " + estudiante.getCarnet());
        }
    }
}
