/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temporizadoralarma;

/**
 *
 * @author rolbi
 */
public class TemporizadorAlarma {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      Temporizador temporizador = new Temporizador();

        // Crear una instancia de Alarma con un tiempo objetivo de 5 segundos
        Alarma alarma = new Alarma(7);

        // Asociar la alarma al temporizador
        temporizador.asociarAlarma(alarma);

        // Iniciar el temporizador
        temporizador.iniciar();
        
         
       
    }
    
}
